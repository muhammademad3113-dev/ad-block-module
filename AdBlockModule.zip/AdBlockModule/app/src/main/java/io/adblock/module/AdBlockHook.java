package io.adblock.module;

import android.net.Uri;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.ByteArrayInputStream;
import java.lang.reflect.Method;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Collections;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage.LoadPackageParam;

/**
 * Generic ad blocker. Works inside LSPatch (embedded in the patched app).
 */
public class AdBlockHook implements IXposedHookLoadPackage {

    private static final String TAG = "AdBlock: ";

    // ---------- Ad domains (matches the domain and all its subdomains) ----------
    private static final String[] AD_HOSTS = {
            "doubleclick.net", "googlesyndication.com", "googleadservices.com",
            "adservice.google.com", "admob.com", "google-analytics.com",
            "applovin.com", "applvn.com", "unityads.unity3d.com",
            "an.facebook.com", "vungle.com", "chartboost.com", "ironsrc.com",
            "supersonicads.com", "inmobi.com", "mopub.com", "adcolony.com",
            "startapp.com", "tapjoy.com", "moatads.com", "adnxs.com",
            "criteo.com", "taboola.com", "outbrain.com", "smaato.net",
            "pubmatic.com", "rubiconproject.com", "mintegral.com",
            "pangleglobal.com", "yandexadexchange.net", "adjust.com"
    };

    // ---------- Ad view class prefixes (hidden when added to a layout) ----------
    private static final String[] AD_VIEW_PREFIXES = {
            "com.google.android.gms.ads.", "com.google.ads.", "com.facebook.ads.",
            "com.applovin.", "com.unity3d.services.banners.", "com.unity3d.ads.",
            "com.mopub.", "com.ironsource.", "com.startapp.", "com.vungle.",
            "com.chartboost.", "com.inmobi.", "com.mbridge.",
            "com.bytedance.sdk.openadsdk.", "com.smaato."
    };

    // ---------- SDK methods turned into no-ops (void methods only) ----------
    private static final String[][] SDK_BLOCKS = {
            {"com.google.android.gms.ads.MobileAds", "initialize"},
            {"com.google.android.gms.ads.AdView", "loadAd"},
            {"com.google.android.gms.ads.BaseAdView", "loadAd"},
            {"com.google.android.gms.ads.admanager.AdManagerAdView", "loadAd"},
            {"com.google.android.gms.ads.AdLoader", "loadAd"},
            {"com.google.android.gms.ads.interstitial.InterstitialAd", "load"},
            {"com.google.android.gms.ads.appopen.AppOpenAd", "load"},
            {"com.google.android.gms.ads.rewarded.RewardedAd", "load"},
            {"com.google.android.gms.ads.rewardedinterstitial.RewardedInterstitialAd", "load"},
            {"com.facebook.ads.AudienceNetworkAds", "initialize"},
            {"com.facebook.ads.AdView", "loadAd"},
            {"com.facebook.ads.InterstitialAd", "loadAd"},
            {"com.applovin.sdk.AppLovinSdk", "initializeSdk"},
            {"com.applovin.mediation.ads.MaxAdView", "loadAd"},
            {"com.applovin.mediation.ads.MaxInterstitialAd", "loadAd"},
            {"com.applovin.mediation.ads.MaxRewardedAd", "loadAd"},
            {"com.unity3d.ads.UnityAds", "initialize"},
            {"com.unity3d.ads.UnityAds", "load"},
            {"com.unity3d.ads.UnityAds", "show"},
            {"com.unity3d.services.banners.BannerView", "load"},
            {"com.ironsource.mediationsdk.IronSource", "init"},
    };

    private static final XC_MethodHook NOOP = new XC_MethodHook() {
        @Override
        protected void beforeHookedMethod(MethodHookParam param) {
            param.setResult(null);
        }
    };

    private static final XC_MethodHook WEB_REQUEST_HOOK = new XC_MethodHook() {
        @Override
        protected void beforeHookedMethod(MethodHookParam param) {
            try {
                WebResourceRequest r = (WebResourceRequest) param.args[1];
                if (r != null && r.getUrl() != null && isAdHost(r.getUrl().getHost())) {
                    param.setResult(new WebResourceResponse(
                            "text/plain", "UTF-8", new ByteArrayInputStream(new byte[0])));
                }
            } catch (Throwable ignored) {
            }
        }
    };

    private static final Map<Class<?>, Boolean> AD_VIEW_CACHE = new ConcurrentHashMap<>();
    private static final Set<Class<?>> HOOKED_CLIENTS =
            Collections.synchronizedSet(new HashSet<Class<?>>());

    @Override
    public void handleLoadPackage(LoadPackageParam lpparam) {
        if (lpparam.packageName.equals("android") || lpparam.packageName.equals("io.adblock.module")) {
            return;
        }
        try { hookDns(); } catch (Throwable t) { log("dns", t); }
        try { hookWebView(); } catch (Throwable t) { log("webview", t); }
        try { hookViews(); } catch (Throwable t) { log("views", t); }
        try { hookSdks(lpparam.classLoader); } catch (Throwable t) { log("sdks", t); }
        XposedBridge.log(TAG + "active in " + lpparam.packageName);
    }

    // ---------- DNS: ad hosts fail to resolve (OkHttp, HttpURLConnection, ...) ----------
    private static void hookDns() {
        XC_MethodHook h = new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam p) {
                String host = (String) p.args[0];
                if (isAdHost(host)) {
                    p.setThrowable(new UnknownHostException(TAG + host));
                }
            }
        };
        XposedHelpers.findAndHookMethod(InetAddress.class, "getAllByName", String.class, h);
        XposedHelpers.findAndHookMethod(InetAddress.class, "getByName", String.class, h);
    }

    // ---------- WebView: block navigation and sub-requests to ad hosts ----------
    private static void hookWebView() {
        XposedBridge.hookAllMethods(WebView.class, "loadUrl", new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam p) {
                if (p.args.length > 0 && p.args[0] instanceof String) {
                    String host = Uri.parse((String) p.args[0]).getHost();
                    if (isAdHost(host)) p.setResult(null);
                }
            }
        });

        XposedHelpers.findAndHookMethod(WebViewClient.class, "shouldInterceptRequest",
                WebView.class, WebResourceRequest.class, WEB_REQUEST_HOOK);

        XposedHelpers.findAndHookMethod(WebView.class, "setWebViewClient", WebViewClient.class,
                new XC_MethodHook() {
                    @Override
                    protected void beforeHookedMethod(MethodHookParam p) {
                        Object client = p.args[0];
                        if (client == null) return;
                        Class<?> c = client.getClass();
                        if (c == WebViewClient.class || !HOOKED_CLIENTS.add(c)) return;
                        try {
                            Method m = c.getDeclaredMethod("shouldInterceptRequest",
                                    WebView.class, WebResourceRequest.class);
                            XposedBridge.hookMethod(m, WEB_REQUEST_HOOK);
                        } catch (NoSuchMethodException ignored) {
                        } catch (Throwable t) {
                            log("client", t);
                        }
                    }
                });
    }

    // ---------- Views: hide ad views as soon as they're added ----------
    private static void hookViews() {
        XposedHelpers.findAndHookMethod(ViewGroup.class, "addView",
                View.class, int.class, ViewGroup.LayoutParams.class, new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam p) {
                        View child = (View) p.args[0];
                        if (child != null && isAdView(child)) {
                            child.setVisibility(View.GONE);
                        }
                    }
                });
    }

    // ---------- Ad SDKs: neutralize init/load/show ----------
    private static void hookSdks(ClassLoader cl) {
        for (String[] entry : SDK_BLOCKS) {
            Class<?> c = XposedHelpers.findClassIfExists(entry[0], cl);
            if (c == null) continue;
            for (Method m : c.getDeclaredMethods()) {
                if (m.getReturnType() != void.class || !m.getName().equals(entry[1])) continue;
                try {
                    XposedBridge.hookMethod(m, NOOP);
                } catch (Throwable t) {
                    log(entry[0] + "#" + entry[1], t);
                }
            }
        }
    }

    // ---------- Helpers ----------
    private static boolean isAdHost(String host) {
        if (host == null) return false;
        host = host.toLowerCase(Locale.ROOT);
        for (String d : AD_HOSTS) {
            if (host.equals(d) || host.endsWith("." + d)) return true;
        }
        return false;
    }

    private static boolean isAdView(View v) {
        Class<?> c = v.getClass();
        Boolean cached = AD_VIEW_CACHE.get(c);
        if (cached == null) {
            String name = c.getName();
            boolean ad = false;
            for (String prefix : AD_VIEW_PREFIXES) {
                if (name.startsWith(prefix)) { ad = true; break; }
            }
            cached = ad;
            AD_VIEW_CACHE.put(c, cached);
        }
        return cached;
    }

    private static void log(String where, Throwable t) {
        XposedBridge.log(TAG + where + " failed: " + t);
    }
}
